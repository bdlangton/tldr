# vim rhubarb

> GitHub extension for fugitive.vim
> https://github.com/tpope/vim-rhubarb

- Browse this file on github (or gitlab or bitbucket). If you visually select lines, it’ll open on Github with the selected lines highlighted

`:Gbrowse`

- Uses `hub` (if installed) instead of git

`:Git`
