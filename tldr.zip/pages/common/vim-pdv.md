# vim pdv

> PHP Documentor for VIM - Generates PHP docblocks
> https://github.com/tobyS/pdv

- Insert php docblock (custom mapping)

`<Leader>d`
