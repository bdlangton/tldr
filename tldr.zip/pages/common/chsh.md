# chsh

> Change user's login shell.

- Change shell:

`chsh -s {{path/to/shell_binary}} {{username}}`
