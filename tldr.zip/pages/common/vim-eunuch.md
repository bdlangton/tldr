# vim eunuch

> Helpers for UNIX
> https://github.com/tpope/vim-eunuch

- Moves a file

`:Move`

- Moves a file (relative to current file's directory)

`:Rename`

- Deletes a files buffer and from disk simultaneously

`:Delete`

- Edit a file with sudo

`:SudoEdit`

- Write a file with sudo

`:SudoWrite`

- Runs a find and puts the results in the quickfix window

`:Cfind`
