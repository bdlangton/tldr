# false

> Returns an exit code of 1.

- Return an exit code of 1:

`false`
