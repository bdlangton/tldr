# whoami

> Print the username associated with the current effective user ID.

- Display currently logged username:

`whoami`

- Display the username after a change in the user ID:

`sudo whoami`
