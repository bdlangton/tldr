# zless

> View compressed files.

- Page through a compressed archive with `less`:

`zless {{file.txt.gz}}`
