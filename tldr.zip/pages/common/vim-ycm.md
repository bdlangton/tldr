# vim youcompleteme

> A code-completion engine for Vim
> https://github.com/ycm-core/YouCompleteMe

- Starts completion suggestions. Multiple hits of tab moves down the list.

`<Tab>`

- Move down the list of suggestions

`C-n`

- Move up the list of suggestions

`C-p`

- Stop completion (close the preview window)

`C-y`
