# vue

> Multi-purpose CLI for Vue.js.
> More information: <https://cli.vuejs.org>.

- Create a new vue project interactively:

`vue create {{project_name}}`

- Create a new project with web UI:

`vue ui`
