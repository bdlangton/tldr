# gtop

> System monitoring dashboard for the terminal.
> More information: <https://github.com/aksakalli/gtop>.

- Show the system stats dashboard:

`gtop`

- Sort by CPU usage:

`c`

- Sort by memory usage:

`m`
