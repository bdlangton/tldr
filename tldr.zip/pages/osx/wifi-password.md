# wifi-password

> Get the password of the wifi.
> More information: <https://github.com/rauchg/wifi-password>.

- Get the password for the wifi you are currently logged onto:

`wifi-password`

- Get the password for the wifi with a specific SSID:

`wifi-password {{ssid}}`

- Print only the password as output:

`wifi-password -q`
